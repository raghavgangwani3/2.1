# HTML & CSS Practical Portfolio

A GitHub Pages-ready portfolio containing all **11 practical exercises** from the supplied HTML & CSS Practical Worksheet.

## Student details
- **Student:** Raghav Gangwani
- **Roll number:** 0925054
- **Course:** B.Com (Programme)
- **Semester:** 3rd
- **Subject:** HTML & CSS

## Practicals included
1. William Blake Biography
2. The Best Movies According to Angela
3. Angela's Recipe for the Best Cinnamon Rolls
4. My Top 5 Favourite Websites
5. I Am a Cat Person
6. I Am a Dog Person
7. It's My Birthday!
8. All the Animals
9. CSS Selectors
10. Colours in Spanish
11. CSS Box Model

## Run locally
Open `index.html` in any modern browser. Each practical has its own folder containing an `index.html` and `style.css`.

## Publish with GitHub Pages
1. Create a GitHub repository (for example, `html-css-practical-portfolio`).
2. Upload the contents of this folder to the repository root (make sure `index.html` is at the root).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish. Your live URL will look like `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Notes
- The animal and birthday pages load illustrative photographs from Unsplash URLs and therefore need an internet connection for those images.
- All page layouts are responsive and include descriptive image alternative text.
- This project uses plain HTML5 and CSS3; no build tools or dependencies are required.
